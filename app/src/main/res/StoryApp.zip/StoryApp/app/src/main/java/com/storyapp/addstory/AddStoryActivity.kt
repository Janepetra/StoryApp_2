package com.storyapp.addstory

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.storyapp.dashboard.MainActivity
import com.storyapp.databinding.ActivityAddStoryBinding
import com.storyapp.viewmodel.DetailStoryViewModel
import com.storyapp.viewmodel.SettingModelFactory
import com.storyapp.viewmodel.SettingPreferences
import com.storyapp.viewmodel.SettingViewModel
import com.storyapp.viewmodel.ViewModelFactory
import com.storyapp.viewmodel.dataStore
import java.io.File

class AddStoryActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAddStoryBinding
    private var token: String? = null
    private var storyViewModel: DetailStoryViewModel? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddStoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        getToken()
        getPhoto()
    }

    private fun getToken() {
        val pref = SettingPreferences.getInstance(dataStore)
        val settingViewModel = ViewModelProvider(this, SettingModelFactory(pref))[SettingViewModel::class.java]
        storyViewModel = ViewModelProvider(this, ViewModelFactory(application))[DetailStoryViewModel::class.java]

        settingViewModel.getUserTokens().observe(this) {
            token = StringBuilder("Bearer ").append(it).toString()
        }
    }

    private fun getPhoto() {
        val myFile = intent?.getSerializableExtra(EXTRA_CAMERAX_IMAGE) as File
        val isFromBackCamera = intent?.getBooleanExtra(EXTRA_CAMERAX_MODE, true) as Boolean
        val resultBitmap = rotateBitmap(
            BitmapFactory.decodeFile(myFile.path),
            isFromBackCamera
        )

        binding.imgAddStory.setImageBitmap(resultBitmap)
        binding.btnAddStory.setOnClickListener {
            if(binding.descAddStory.text.isNotEmpty()) {
                uploadPic(myFile, binding.descAddStory.text.toString())
            } else {
                Toast.makeText(this, "Please filled story description", Toast.LENGTH_SHORT).show()
            }
        }
        storyViewModel?.let {
            it.addStory.observe(this) {
                if(true) {
                    Toast.makeText(this, "photo has been selected", Toast.LENGTH_SHORT).show()
                }
            }
            it.isLoading.observe(this) {isLoading ->
                binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
            }
        }
    }

    private fun uploadPic(image: File, description: String) {
        if (token != null) {
            storyViewModel?.addStory(token!!, image, description)
            AlertDialog.Builder(this).apply {
                setTitle("Yeah!")
                setMessage("Your story has been successfully uploaded!")
                val intent = Intent(this@AddStoryActivity, MainActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
                startActivity(intent)
                finish()
            }
        } else {
            Toast.makeText(this, "You are unauthorized, please login again", Toast.LENGTH_SHORT).show()
        }
    }

    private fun rotateBitmap(bitmap: Bitmap, isFromBackCamera: Boolean = false): Bitmap {
        val matrix = Matrix()
        return if (isFromBackCamera) {
            matrix.postRotate(90f)
            Bitmap.createBitmap(
                bitmap,
                0,
                0,
                bitmap.width,
                bitmap.height,
                matrix,
                true
            )
        } else {
            matrix.postRotate(-90f)
            matrix.postScale(-1f, 1f, bitmap.width / 2f, bitmap.height / 2f)
            Bitmap.createBitmap(
                bitmap,
                0,
                0,
                bitmap.width,
                bitmap.height,
                matrix,
                true
            )
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        finish()
        return super.onSupportNavigateUp()
    }

    companion object {
        const val EXTRA_CAMERAX_IMAGE = "CameraX Image"
        const val EXTRA_CAMERAX_MODE = "CameraX_Mode"
    }
}