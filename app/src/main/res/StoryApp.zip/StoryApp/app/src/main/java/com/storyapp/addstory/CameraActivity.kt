package com.storyapp.addstory

import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Environment
import android.util.Log
import android.view.OrientationEventListener
import android.view.Surface
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import com.storyapp.databinding.ActivityCameraBinding
import com.storyapp.viewmodel.SettingModelFactory
import com.storyapp.viewmodel.SettingPreferences
import com.storyapp.viewmodel.SettingViewModel
import com.storyapp.viewmodel.dataStore
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Locale

class CameraActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCameraBinding
    private lateinit var openGallery: ActivityResultLauncher<Intent>
    private var cameraSelector: CameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
    private var imageCapture: ImageCapture? = null
    private val FILENAME_FORMAT = "dd-MMM-yyyy"
    private val timeStamp: String = SimpleDateFormat(
        FILENAME_FORMAT, Locale.KOREA
    ).format(System.currentTimeMillis())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCameraBinding.inflate(layoutInflater)
        setContentView(binding.root)

        btnAction()
        initGallery()
    }

    private fun btnAction() {
        binding.btnCamera.setOnClickListener {
            takePic()
        }
        binding.btnFlipcam.setOnClickListener {
            cameraSelector =
                if (cameraSelector == CameraSelector.DEFAULT_BACK_CAMERA) CameraSelector.DEFAULT_FRONT_CAMERA
                else CameraSelector.DEFAULT_BACK_CAMERA
            startCamera()
        }
        binding.btnGallery.setOnClickListener {
            startGallery()
        }
        startCamera()
    }

    private fun startCamera() {
        //Membuat objek ProcessCameraProviderFuture untuk mendapatkan instance ProcessCameraProvider
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            //Mendapatkan instance ProcessCameraProvider
            val cameraProvider: ProcessCameraProvider = cameraProviderFuture.get()
            val preview = Preview.Builder()
                .build()
                .also {
                    //Mengatur SurfaceProvider untuk menampilkan pratinjau pada SurfaceView
                    it.setSurfaceProvider(binding.pvCamera.surfaceProvider)
                }

            imageCapture = ImageCapture.Builder().build()

            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(
                    this,
                    cameraSelector,
                    preview,
                    imageCapture
                )

            } catch (exc: Exception) {
                Toast.makeText(
                    this@CameraActivity,
                    "Gagal memunculkan kamera.",
                    Toast.LENGTH_SHORT
                ).show()
                Log.e(TAG, "startCamera: ${exc.message}")
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun takePic() {
        //check is file null or not
        val imageCapture = imageCapture ?: return
        //make object file untuk menyimpan photo yg diambil
        val photoFile = createCustomTempFile(application)
        val outputOptions = ImageCapture.OutputFileOptions.Builder(photoFile).build()

        imageCapture.takePicture(
            outputOptions,
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                    val intent = Intent(this@CameraActivity, AddStoryActivity::class.java)
                    intent.putExtra(AddStoryActivity.EXTRA_CAMERAX_IMAGE, photoFile)
                    intent.putExtra(
                        AddStoryActivity.EXTRA_CAMERAX_MODE, cameraSelector == CameraSelector.DEFAULT_BACK_CAMERA
                    )
                    this@CameraActivity.finish()
                    startActivity(intent)
                }

                override fun onError(exc: ImageCaptureException) {
                    Toast.makeText(
                        this@CameraActivity,
                        "Gagal mengambil gambar.",
                        Toast.LENGTH_SHORT
                    ).show()
                    Log.e(TAG, "onError: ${exc.message}")
                }
            }
        )
    }

    private fun createCustomTempFile(context: Context): File {
        // get direktori penyimpanan eksternal utk storyApp di Pictures
        val storageDir: File? = context.getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        // make temporary file with time format
        return File.createTempFile(timeStamp, ".jpg", storageDir)
    }

    private fun initGallery() {
        openGallery = registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result ->
            if (result.resultCode == RESULT_OK) {
                //get Uri dari data
                val selectedImg: Uri = result.data?.data as Uri
                //convert uri diatas menggunakan fun uriToFile
                val myFile = uriToFile(selectedImg, this@CameraActivity)
                //send data in putExtra
                val intent = Intent(this@CameraActivity, AddStoryActivity::class.java)
                intent.putExtra(AddStoryActivity.EXTRA_CAMERAX_IMAGE, myFile)
                intent.putExtra(
                    AddStoryActivity.EXTRA_CAMERAX_MODE,
                    cameraSelector == CameraSelector.DEFAULT_BACK_CAMERA
                )
                this@CameraActivity.finish()
                startActivity(intent)
            }
        }
    }

    private fun startGallery() {
        val intent = Intent()
        intent.action = Intent.ACTION_GET_CONTENT
        //menetukan tipe data yaitu image
        intent.type = "image/*"
        //Membuat Intent chooser untuk menampilkan aplikasi yang dapat menangani tipe data
        val chooser = Intent.createChooser(intent, "Pick a Photo")
        openGallery.launch(chooser)
    }

    fun uriToFile(selectedImg: Uri, context: Context): File {
        // Mendapatkan ContentResolver dari konteks
        val contentResolver: ContentResolver = context.contentResolver
        // Membuat objek File menggunakan fungsi createCustomTempFile
        val myFile = createCustomTempFile(context)
        // Membuka InputStream dari Uri yang dipilih
        val inputStream = contentResolver.openInputStream(selectedImg) as InputStream
        // Membuat OutputStream dari objek File
        val outputStream: OutputStream = FileOutputStream(myFile)
        // Menyalin data dari InputStream ke OutputStream menggunakan buffer
        val buffer = ByteArray(1024)
        var lenght: Int

        while (inputStream.read(buffer).also { lenght = it } > 0) outputStream.write(buffer, 0, lenght)
        outputStream.close()
        inputStream.close()

        // Mengembalikan objek File yang telah dibuat dan diisi dengan data dari Uri
        return myFile
    }

    //digunakan untuk mendengarkan perubahan orientasi perangkat.
    private val orientationEventListener by lazy {
        object : OrientationEventListener(this) {
            //Metode ini dipanggil ketika terjadi perubahan orientasi perangkat
            override fun onOrientationChanged(orientation: Int) {
                if (orientation == ORIENTATION_UNKNOWN) {
                    return
                }

                val rotation = when (orientation) {
                    in 45 until 135 -> Surface.ROTATION_270
                    in 135 until 225 -> Surface.ROTATION_180
                    in 225 until 315 -> Surface.ROTATION_90
                    else -> Surface.ROTATION_0
                }

                imageCapture?.targetRotation = rotation
            }
        }
    }

    override fun onStart() {
        super.onStart()
        orientationEventListener.enable()
    }

    override fun onStop() {
        super.onStop()
        orientationEventListener.disable()
    }

    companion object {
        private const val TAG = "CameraActivity"
    }
}