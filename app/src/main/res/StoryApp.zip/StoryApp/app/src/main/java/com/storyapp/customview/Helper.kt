package com.storyapp.customview

object Helper {

    val pattern = Regex("^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$")

    enum class data {
        Name, ImageURL, Description, UploadTime
    }
}